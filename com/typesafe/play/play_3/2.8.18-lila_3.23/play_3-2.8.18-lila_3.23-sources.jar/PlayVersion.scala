package play.core

object PlayVersion {
  val current = "2.8.18-lila_3.23"
  val scalaVersion = "3.8.4"
  val sbtVersion = "1.12.13"
  val akkaVersion = "2.6.21"
  val akkaHttpVersion = "10.2.10"
}
