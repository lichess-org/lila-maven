package play.core

object PlayVersion {
  val current = "2.0.0-RC1"
  val scalaVersion = "3.8.4"
  val sbtVersion = "1.12.12"
}
