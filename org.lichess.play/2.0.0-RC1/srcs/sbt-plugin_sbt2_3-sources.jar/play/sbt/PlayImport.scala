/*
 * Copyright (C) from 2022 The Play Framework Contributors <https://github.com/playframework>, 2011-2021 Lightbend Inc. <https://www.lightbend.com>
 */

package play.sbt

import sbt._
import sbt.librarymanagement.ModuleID
import sbt.librarymanagement.syntax._
import sbt.internal.util.FeedbackProvidedException

/**
 * Declares the default imports for Play plugins.
 */
object PlayImport {
  val Production = sbt.librarymanagement.Configuration.of("Production", "production")

  def component(id: String) = "com.typesafe.play" %% id % play.core.PlayVersion.current

  def movedExternal(msg: String): ModuleID = {
    System.err.println(msg)
    class ComponentExternalisedException extends RuntimeException(msg) with FeedbackProvidedException
    throw new ComponentExternalisedException
  }

  val playCore = component("play")

  val nettyServer = component("play-netty-server")

  val logback = component("play-logback")

  object PlayKeys {
    val playDefaultPort    = SettingKey[Int]("playDefaultPort", "The default port that Play runs on")
    val playDefaultAddress = SettingKey[String]("playDefaultAddress", "The default address that Play runs on")

    val playPlugin = SettingKey[Boolean]("playPlugin")

    val devSettings = SettingKey[Seq[(String, String)]]("playDevSettings")

    val assetsPrefix = SettingKey[String]("assetsPrefix")
  }
}
