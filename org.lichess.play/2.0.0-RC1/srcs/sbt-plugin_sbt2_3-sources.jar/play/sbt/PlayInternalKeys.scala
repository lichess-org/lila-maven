/*
 * Copyright (C) from 2022 The Play Framework Contributors <https://github.com/playframework>, 2011-2021 Lightbend Inc. <https://www.lightbend.com>
 */

package play.sbt

import sbt._
import sbt.Keys._

object PlayInternalKeys extends sbt.BuildSyntax {

  val playDependencyClasspath = taskKey[Def.Classpath](
    "The classpath containing all the jar dependencies of the project"
  )
  val playCommonClassloader = taskKey[ClassLoader](
    "The common classloader, is used to hold H2 to ensure in memory databases don't get lost between invocations of run"
  )
  val playAssetsClassLoader = taskKey[ClassLoader => ClassLoader](
    "Function that creates a classloader from a given parent that contains all the assets."
  )

  val playStop = taskKey[Unit]("Stop Play, if it has been started in non blocking mode")
}
