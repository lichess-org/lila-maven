
package play.routes.compiler.inject.twirl

import _root_.play.twirl.api.TwirlFeatureImports._
import _root_.play.twirl.api.TwirlHelperImports._
import _root_.play.twirl.api.Html
import _root_.play.twirl.api.JavaScript
import _root_.play.twirl.api.Txt
import _root_.play.twirl.api.Xml
/*1.2*/import play.routes.compiler._
/*2.2*/import play.routes.compiler.templates._
/*3.2*/import InjectedRoutesGenerator.Dependency

object forwardsRouter extends _root_.play.twirl.api.BaseScalaTemplate[play.routes.compiler.ScalaFormat.Appendable,_root_.play.twirl.api.Format[play.routes.compiler.ScalaFormat.Appendable]](play.routes.compiler.ScalaFormat) with _root_.play.twirl.api.Template6[RoutesSourceInfo,Option[String],Seq[String],Seq[Dependency[Rule]],Seq[(String, Seq[Dependency[Rule]])],Seq[Dependency[Include]],play.routes.compiler.ScalaFormat.Appendable] {

  /**/
  def apply/*5.2*/(sourceInfo: RoutesSourceInfo, pkg: Option[String], imports: Seq[String],
  deps: Seq[Dependency[Rule]], pathRules: Seq[(String, Seq[Dependency[Rule]])], includes: Seq[Dependency[Include]]):play.routes.compiler.ScalaFormat.Appendable = {
    _display_ {
      {


Seq[Any](format.raw/*7.1*/("""// @GENERATOR:play-routes-compiler
// @SOURCE:"""),_display_(/*8.14*/sourceInfo/*8.24*/.source),format.raw/*8.31*/("""

"""),format.raw/*10.1*/("""package router
"""),_display_(/*11.2*/for(p <- pkg) yield /*11.15*/ {_display_(Seq[Any](format.raw/*11.17*/("""package """),_display_(/*11.26*/p)))}),format.raw/*11.28*/("""

"""),format.raw/*13.1*/("""import play.core.routing._

import play.api.mvc._
"""),_display_(/*16.2*/for(i <- imports) yield /*16.19*/ {_display_(Seq[Any](format.raw/*16.21*/("""
"""),format.raw/*17.1*/("""import """),_display_(if(!i.startsWith("_root_."))/*17.37*/{_display_(Seq[Any](format.raw/*17.38*/("""_root_.""")))} else {null} ),_display_(/*17.47*/i)))}),format.raw/*17.49*/("""

"""),format.raw/*19.1*/("""final class Routes(
  override val errorHandler: play.api.http.HttpErrorHandler, """),_display_(/*20.63*/for(dep <- deps) yield /*20.79*/{_display_(Seq[Any](format.raw/*20.80*/("""
  """),_display_(/*21.4*/markLines(dep.rule)),format.raw/*21.23*/("""
  """),_display_(/*22.4*/dep/*22.7*/.ident),format.raw/*22.13*/(""": """),_display_(/*22.16*/dep/*22.19*/.clazz),format.raw/*22.25*/(""",""")))}),format.raw/*22.27*/("""
"""),format.raw/*23.1*/(""") extends GeneratedRouter """),_display_(/*23.28*/ob),format.raw/*23.30*/("""

  """),format.raw/*25.3*/("""final val prefix: String = "/"
  def withPrefix(addPrefix: String): Routes = ???

"""),_display_(/*28.2*/for((rules, pathIndex) <- pathRules.map(_._2).zipWithIndex) yield /*28.61*/{_display_(Seq[Any](format.raw/*28.62*/("""
"""),_display_(/*29.2*/for((dep, index) <- rules.zipWithIndex) yield /*29.41*/{_display_(_display_(/*29.43*/dep/*29.46*/.rule/*29.51*/ match/*29.57*/ {/*30.1*/case route @ Route(verb, path, call, comments, modifiers) =>/*30.61*/ {_display_(Seq[Any](format.raw/*30.63*/("""
  """),_display_(/*31.4*/markLines(route)),format.raw/*31.20*/("""
  """),format.raw/*32.3*/("""private val """),_display_(/*32.16*/routeIdentifier(route, pathIndex, index)),format.raw/*32.56*/(""" """),format.raw/*32.57*/("""= Route(""""),_display_(/*32.67*/verb/*32.71*/.value),format.raw/*32.77*/("""",
    PathPattern(List("""),_display_(/*33.23*/path/*33.27*/.parts.map(_.toString).mkString(", ")),format.raw/*33.64*/("""))
  )
""")))}/*36.1*/case include @ Include(path, router) =>/*36.40*/ {_display_(Seq[Any](format.raw/*36.42*/("""
  """),_display_(/*37.4*/markLines(include)),format.raw/*37.22*/("""
  """),format.raw/*38.3*/("""private val prefixed_"""),_display_(/*38.25*/(dep.ident)),format.raw/*38.36*/("""_"""),_display_(/*38.38*/(pathIndex * 1000 + index)),format.raw/*38.64*/(""" """),format.raw/*38.65*/("""= Include("""),_display_(/*38.76*/(dep.ident)),format.raw/*38.87*/(""")
""")))}}))})))}),format.raw/*39.5*/("""

  """),format.raw/*41.3*/("""val pathRouters: Map[String, PartialFunction[RequestHeader, Handler]] = Map(
    """),_display_(/*42.6*/for(((path, rules), pathIndex) <- pathRules.zipWithIndex) yield /*42.63*/ {_display_(Seq[Any](format.raw/*42.65*/("""
      """),format.raw/*43.7*/("""""""),_display_(/*43.9*/path),format.raw/*43.13*/("""" -> """),_display_(/*43.19*/ob),format.raw/*43.21*/("""
        """),_display_(/*44.10*/for((dep, index) <- rules.zipWithIndex) yield /*44.49*/{_display_(_display_(/*44.51*/dep/*44.54*/.rule/*44.59*/ match/*44.65*/ {/*45.9*/case include: Include =>/*45.33*/ {_display_(Seq[Any](format.raw/*45.35*/("""
          """),_display_(/*46.12*/markLines(include)),format.raw/*46.30*/("""
          case prefixed_"""),_display_(/*47.26*/(dep.ident)),format.raw/*47.37*/("""_"""),_display_(/*47.39*/(pathIndex * 1000 + index)),format.raw/*47.65*/("""(handler) => handler
        """)))}/*49.9*/case route: Route =>/*49.29*/ {_display_(Seq[Any](format.raw/*49.31*/("""
          """),_display_(/*50.12*/markLines(route)),format.raw/*50.28*/("""
          case """),_display_(/*51.17*/(routeIdentifier(route, pathIndex, index))),format.raw/*51.59*/("""("""),_display_(if(route.call.routeParams.forall(_.fixed))/*51.103*/{_display_(Seq[Any](format.raw/*51.104*/("""_""")))}else/*51.110*/{_display_(Seq[Any](format.raw/*51.111*/("""params""")))}),format.raw/*51.118*/(""") =>
            named(""""),_display_(/*52.21*/(route.call.controller)),format.raw/*52.44*/("""."""),_display_(/*52.46*/(route.call.method)),format.raw/*52.65*/("""") """),_display_(/*52.69*/ob),format.raw/*52.71*/("""
              """),format.raw/*53.15*/("""call"""),_display_(/*53.20*/(routeBinding(route))),format.raw/*53.41*/(""" """),_display_(/*53.43*/ob),format.raw/*53.45*/(""" """),_display_(/*53.47*/localNames(route)),format.raw/*53.64*/("""
                  """),_display_(/*54.20*/injectedControllerMethodCall(route, dep.ident, x => safeKeyword(x.nameClean))),format.raw/*54.97*/("""
              """),_display_(/*55.16*/cb),format.raw/*55.18*/("""
            """),_display_(/*56.14*/cb),format.raw/*56.16*/("""
        """)))}}))}),format.raw/*58.11*/("""
      """),_display_(/*59.8*/cb),format.raw/*59.10*/(""",
    """)))}),format.raw/*60.6*/("""
  """),format.raw/*61.3*/(""")

  val routes: PartialFunction[RequestHeader, Handler] =
    """),_display_(if(pathRules.isEmpty)/*64.27*/ {_display_(Seq[Any](format.raw/*64.29*/(""" """),format.raw/*64.30*/("""Map.empty """)))}else/*64.47*/{_display_(Seq[Any](_display_(/*64.49*/ob),format.raw/*64.51*/("""
      """),format.raw/*65.7*/("""val emptyPathRouter = pathRouters get ""
      Function unlift """),_display_(/*66.24*/ob),format.raw/*66.26*/(""" """),format.raw/*66.27*/("""(req: RequestHeader) =>
        pathRouters.get(req.path.drop(1).takeWhile(_ != '/')).orElse(emptyPathRouter).flatMap(_ lift req)
      """),_display_(/*68.8*/cb),format.raw/*68.10*/("""
    """),_display_(/*69.6*/cb)))}),format.raw/*69.9*/("""
"""),_display_(/*70.2*/cb),format.raw/*70.4*/("""
"""))
      }
    }
  }

  def render(sourceInfo:RoutesSourceInfo,pkg:Option[String],imports:Seq[String],deps:Seq[Dependency[Rule]],pathRules:Seq[(String, Seq[Dependency[Rule]])],includes:Seq[Dependency[Include]]): play.routes.compiler.ScalaFormat.Appendable = apply(sourceInfo,pkg,imports,deps,pathRules,includes)

  def f:((RoutesSourceInfo,Option[String],Seq[String],Seq[Dependency[Rule]],Seq[(String, Seq[Dependency[Rule]])],Seq[Dependency[Include]]) => play.routes.compiler.ScalaFormat.Appendable) = (sourceInfo,pkg,imports,deps,pathRules,includes) => apply(sourceInfo,pkg,imports,deps,pathRules,includes)

  def ref: this.type = this

}


              /*
                  -- GENERATED --
                  SOURCE: dev-mode/routes-compiler/src/main/twirl/play/routes/compiler/inject/forwardsRouter.scala.twirl
                  HASH: 3b5a976e302132bd616cc1e866b4d7d23b91ebc1
                  MATRIX: 292->1|329->32|376->73|880->117|1170->307|1243->356|1261->366|1288->373|1317->375|1359->391|1388->404|1428->406|1464->415|1490->417|1519->419|1596->470|1629->487|1669->489|1697->490|1760->526|1799->527|1851->536|1877->538|1906->540|2015->622|2047->638|2086->639|2116->643|2156->662|2186->666|2197->669|2224->675|2254->678|2266->681|2293->687|2326->689|2354->690|2408->717|2431->719|2462->723|2571->806|2646->865|2685->866|2713->868|2768->907|2798->909|2810->912|2824->917|2839->923|2849->926|2918->986|2958->988|2988->992|3025->1008|3055->1011|3095->1024|3156->1064|3185->1065|3222->1075|3235->1079|3262->1085|3314->1110|3327->1114|3385->1151|3411->1160|3459->1199|3499->1201|3529->1205|3568->1223|3598->1226|3647->1248|3679->1259|3708->1261|3755->1287|3784->1288|3822->1299|3854->1310|3895->1316|3926->1320|4034->1402|4107->1459|4147->1461|4181->1468|4209->1470|4234->1474|4267->1480|4290->1482|4327->1492|4382->1531|4412->1533|4424->1536|4438->1541|4453->1547|4463->1558|4496->1582|4536->1584|4575->1596|4614->1614|4667->1640|4699->1651|4728->1653|4775->1679|4823->1718|4852->1738|4892->1740|4931->1752|4968->1768|5012->1785|5075->1827|5147->1871|5187->1872|5213->1878|5253->1879|5292->1886|5344->1911|5388->1934|5417->1936|5457->1955|5488->1959|5511->1961|5554->1976|5586->1981|5628->2002|5657->2004|5680->2006|5709->2008|5747->2025|5794->2045|5892->2122|5935->2138|5958->2140|5999->2154|6022->2156|6067->2177|6101->2185|6124->2187|6161->2194|6191->2197|6303->2282|6343->2284|6372->2285|6406->2302|6445->2304|6468->2306|6502->2313|6593->2377|6616->2379|6645->2380|6808->2517|6831->2519|6863->2525|6889->2528|6917->2530|6939->2532
                  LINES: 10->1|11->2|12->3|17->5|23->7|24->8|24->8|24->8|26->10|27->11|27->11|27->11|27->11|27->11|29->13|32->16|32->16|32->16|33->17|33->17|33->17|33->17|33->17|35->19|36->20|36->20|36->20|37->21|37->21|38->22|38->22|38->22|38->22|38->22|38->22|38->22|39->23|39->23|39->23|41->25|44->28|44->28|44->28|45->29|45->29|45->29|45->29|45->29|45->29|45->30|45->30|45->30|46->31|46->31|47->32|47->32|47->32|47->32|47->32|47->32|47->32|48->33|48->33|48->33|50->36|50->36|50->36|51->37|51->37|52->38|52->38|52->38|52->38|52->38|52->38|52->38|52->38|53->39|55->41|56->42|56->42|56->42|57->43|57->43|57->43|57->43|57->43|58->44|58->44|58->44|58->44|58->44|58->44|58->45|58->45|58->45|59->46|59->46|60->47|60->47|60->47|60->47|61->49|61->49|61->49|62->50|62->50|63->51|63->51|63->51|63->51|63->51|63->51|63->51|64->52|64->52|64->52|64->52|64->52|64->52|65->53|65->53|65->53|65->53|65->53|65->53|65->53|66->54|66->54|67->55|67->55|68->56|68->56|69->58|70->59|70->59|71->60|72->61|75->64|75->64|75->64|75->64|75->64|75->64|76->65|77->66|77->66|77->66|79->68|79->68|80->69|80->69|81->70|81->70
                  -- GENERATED --
              */
          