
package play.routes.compiler.static.twirl

import _root_.play.twirl.api.TwirlFeatureImports._
import _root_.play.twirl.api.TwirlHelperImports._
import _root_.play.twirl.api.Html
import _root_.play.twirl.api.JavaScript
import _root_.play.twirl.api.Txt
import _root_.play.twirl.api.Xml
/*1.2*/import play.routes.compiler._
/*2.2*/import play.routes.compiler.templates._

object reverseRouter extends _root_.play.twirl.api.BaseScalaTemplate[play.routes.compiler.ScalaFormat.Appendable,_root_.play.twirl.api.Format[play.routes.compiler.ScalaFormat.Appendable]](play.routes.compiler.ScalaFormat) with _root_.play.twirl.api.Template6[RoutesSourceInfo,Option[String],Seq[String],Seq[Route],Boolean,Route => Boolean,play.routes.compiler.ScalaFormat.Appendable] {

  /**/
  def apply/*3.2*/(sourceInfo: RoutesSourceInfo, pkg: Option[String], imports: Seq[String], routes: Seq[Route], namespaceReverseRouter: Boolean, useInjector: Route => Boolean):play.routes.compiler.ScalaFormat.Appendable = {
    _display_ {
      {


Seq[Any](format.raw/*4.1*/("""// @GENERATOR:play-routes-compiler
// @SOURCE:"""),_display_(/*5.14*/sourceInfo/*5.24*/.source),format.raw/*5.31*/("""

"""),format.raw/*7.1*/("""import play.api.mvc."""),format.raw/*7.21*/("""{"""),format.raw/*7.22*/("""Call, PathBindable"""),format.raw/*7.40*/("""}"""),format.raw/*7.41*/("""
"""),format.raw/*8.1*/("""import play.core.routing."""),format.raw/*8.26*/("""{"""),format.raw/*8.27*/("""dynamicString"""),format.raw/*8.40*/("""}"""),format.raw/*8.41*/("""

"""),_display_(/*10.2*/for(i <- imports) yield /*10.19*/ {_display_(Seq[Any](format.raw/*10.21*/("""
"""),format.raw/*11.1*/("""import """),_display_(if(!i.startsWith("_root_."))/*11.37*/{_display_(Seq[Any](format.raw/*11.38*/("""_root_.""")))} else {null} ),_display_(/*11.47*/i)))}),format.raw/*11.49*/("""

"""),_display_(/*13.2*/markLines(routes: _*)),format.raw/*13.23*/("""
"""),format.raw/*14.1*/("""package routes """),_display_(/*14.17*/ob),format.raw/*14.19*/("""

"""),_display_(/*16.2*/for((controller, routes) <- groupRoutesByController(routes)) yield /*16.62*/ {_display_(Seq[Any](format.raw/*16.64*/("""
  """),_display_(/*17.4*/markLines(routes: _*)),format.raw/*17.25*/("""
  """),format.raw/*18.3*/("""object """),_display_(/*18.11*/(controller.replace(".", "_"))),format.raw/*18.41*/(""" """),_display_(/*18.43*/ob),format.raw/*18.45*/("""

  """),_display_(/*20.4*/for(((method, _), routes) <- groupRoutesByMethod(routes)) yield /*20.61*/ {_display_(_display_(/*20.64*/routes/*20.70*/ match/*20.76*/ {/*21.3*/case Seq(route: Route) =>/*21.28*/ {_display_(Seq[Any](format.raw/*21.30*/("""
    """),_display_(/*22.6*/markLines(route)),format.raw/*22.22*/("""
    """),format.raw/*23.5*/("""def """),_display_(/*23.10*/(method)),_display_(/*23.19*/(reverseSignature(routes))),format.raw/*23.45*/(""": Call = """),_display_(/*23.55*/ob),format.raw/*23.57*/("""
      """),_display_(/*24.8*/reverseRouteContext(route)),format.raw/*24.34*/("""
      """),_display_(/*25.8*/reverseCall(route)),format.raw/*25.26*/("""
    """),_display_(/*26.6*/cb),format.raw/*26.8*/("""
  """)))}/*28.3*/case _ =>/*28.12*/ {_display_(Seq[Any](format.raw/*28.14*/("""
    """),_display_(/*29.6*/markLines(routes: _*)),format.raw/*29.27*/("""
    """),format.raw/*30.5*/("""def """),_display_(/*30.10*/(method)),_display_(/*30.19*/(reverseSignature(routes))),format.raw/*30.45*/(""": Call = """),_display_(/*30.55*/ob),format.raw/*30.57*/("""
    """),_display_(/*31.6*/defining(reverseParameters(routes))/*31.41*/ { params =>_display_(Seq[Any](format.raw/*31.53*/("""
      """),format.raw/*32.7*/("""("""),_display_(/*32.9*/reverseMatchParameters(params, true)),format.raw/*32.45*/(""") match """),_display_(/*32.54*/ob),format.raw/*32.56*/("""
      """),_display_(/*33.8*/reverseUniqueConstraints(routes, params)/*33.48*/ { (route, parameters, parameterConstraints, localNames) =>_display_(Seq[Any](format.raw/*33.107*/("""
        """),_display_(/*34.10*/markLines(route)),format.raw/*34.26*/("""
        case ("""),_display_(/*35.16*/parameters),format.raw/*35.26*/(""") """),_display_(/*35.29*/parameterConstraints),format.raw/*35.49*/(""" """),format.raw/*35.50*/("""=>
          """),_display_(/*36.12*/reverseRouteContext(route)),format.raw/*36.38*/("""
          """),_display_(/*37.12*/reverseCall(route, localNames)),format.raw/*37.42*/("""
      """)))}),format.raw/*38.8*/("""
      """),_display_(/*39.8*/cb),format.raw/*39.10*/("""
    """)))}),format.raw/*40.6*/("""
    """),_display_(/*41.6*/cb),format.raw/*41.8*/("""
  """)))}}))}),format.raw/*42.6*/("""
  """),_display_(/*43.4*/cb),format.raw/*43.6*/("""
""")))}),format.raw/*44.2*/("""
"""),_display_(/*45.2*/cb),format.raw/*45.4*/("""
"""))
      }
    }
  }

  def render(sourceInfo:RoutesSourceInfo,pkg:Option[String],imports:Seq[String],routes:Seq[Route],namespaceReverseRouter:Boolean,useInjector:Route => Boolean): play.routes.compiler.ScalaFormat.Appendable = apply(sourceInfo,pkg,imports,routes,namespaceReverseRouter,useInjector)

  def f:((RoutesSourceInfo,Option[String],Seq[String],Seq[Route],Boolean,Route => Boolean) => play.routes.compiler.ScalaFormat.Appendable) = (sourceInfo,pkg,imports,routes,namespaceReverseRouter,useInjector) => apply(sourceInfo,pkg,imports,routes,namespaceReverseRouter,useInjector)

  def ref: this.type = this

}


              /*
                  -- GENERATED --
                  SOURCE: dev-mode/routes-compiler/src/main/twirl/play/routes/compiler/static/reverseRouter.scala.twirl
                  HASH: 1a0b58fee2d21267f70f93c16813f16ee2f884bf
                  MATRIX: 292->1|329->32|782->73|1040->231|1113->280|1131->290|1158->297|1186->299|1233->319|1261->320|1306->338|1334->339|1361->340|1413->365|1441->366|1481->379|1509->380|1538->383|1571->400|1611->402|1639->403|1702->439|1741->440|1793->449|1819->451|1848->454|1890->475|1918->476|1961->492|1984->494|2013->497|2089->557|2129->559|2159->563|2201->584|2231->587|2266->595|2317->625|2346->627|2369->629|2400->634|2473->691|2504->694|2519->700|2534->706|2544->711|2578->736|2618->738|2650->744|2687->760|2719->765|2751->770|2780->779|2827->805|2864->815|2887->817|2921->825|2968->851|3002->859|3041->877|3073->883|3095->885|3117->892|3135->901|3175->903|3207->909|3249->930|3281->935|3313->940|3342->949|3389->975|3426->985|3449->987|3481->993|3525->1028|3575->1040|3609->1047|3637->1049|3694->1085|3730->1094|3753->1096|3787->1104|3836->1144|3934->1203|3971->1213|4008->1229|4051->1245|4082->1255|4112->1258|4153->1278|4182->1279|4223->1293|4270->1319|4309->1331|4360->1361|4398->1369|4432->1377|4455->1379|4491->1385|4523->1391|4545->1393|4583->1399|4613->1403|4635->1405|4667->1407|4695->1409|4717->1411
                  LINES: 10->1|11->2|16->3|21->4|22->5|22->5|22->5|24->7|24->7|24->7|24->7|24->7|25->8|25->8|25->8|25->8|25->8|27->10|27->10|27->10|28->11|28->11|28->11|28->11|28->11|30->13|30->13|31->14|31->14|31->14|33->16|33->16|33->16|34->17|34->17|35->18|35->18|35->18|35->18|35->18|37->20|37->20|37->20|37->20|37->20|37->21|37->21|37->21|38->22|38->22|39->23|39->23|39->23|39->23|39->23|39->23|40->24|40->24|41->25|41->25|42->26|42->26|43->28|43->28|43->28|44->29|44->29|45->30|45->30|45->30|45->30|45->30|45->30|46->31|46->31|46->31|47->32|47->32|47->32|47->32|47->32|48->33|48->33|48->33|49->34|49->34|50->35|50->35|50->35|50->35|50->35|51->36|51->36|52->37|52->37|53->38|54->39|54->39|55->40|56->41|56->41|57->42|58->43|58->43|59->44|60->45|60->45
                  -- GENERATED --
              */
          